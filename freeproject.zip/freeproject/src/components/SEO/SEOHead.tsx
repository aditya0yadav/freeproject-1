import React from 'react';
import { Helmet } from 'react-helmet-async';

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string;
  image?: string;
  url?: string;
  type?: string;
  structuredData?: object;
  canonical?: string;
}

export const SEOHead: React.FC<SEOHeadProps> = ({
  title = "Rentwala - Find Your Dream Property in India | Real Estate Platform",
  description = "Discover your perfect property with Rentwala, India's leading real estate platform. Browse 25,000+ properties across Delhi-NCR, Gurgaon, Noida. Expert agents, transparent pricing, 12+ years experience.",
  keywords = "real estate India, property for sale, buy property Delhi, Gurgaon properties, Noida real estate, property investment, dream home India, real estate agent",
  image = "https://rentwala.com/og-image.jpg",
  url = "https://rentwala.com/",
  type = "website",
  structuredData,
  canonical
}) => {
  return (
    <Helmet>
      {/* Basic Meta Tags */}
      <title>{title}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />
      <meta name="robots" content="index, follow" />
      
      {/* Canonical URL */}
      {canonical && <link rel="canonical" href={canonical} />}
      
      {/* Open Graph / Facebook */}
      <meta property="og:type" content={type} />
      <meta property="og:url" content={url} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={image} />
      <meta property="og:site_name" content="Rentwala" />
      <meta property="og:locale" content="en_IN" />
      
      {/* Twitter */}
      <meta property="twitter:card" content="summary_large_image" />
      <meta property="twitter:url" content={url} />
      <meta property="twitter:title" content={title} />
      <meta property="twitter:description" content={description} />
      <meta property="twitter:image" content={image} />
      <meta property="twitter:site" content="@rentwala" />
      
      {/* Structured Data */}
      {structuredData && (
        <script type="application/ld+json">
          {JSON.stringify(structuredData)}
        </script>
      )}
    </Helmet>
  );
};