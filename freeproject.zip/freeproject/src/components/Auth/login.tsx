import React, { useState } from 'react';
import AuthFlipCard from './AuthFlipCard';
import { User, LogOut, Shield } from 'lucide-react';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

function LoginPage() {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);

  const handleAuthSuccess = (userData: User, authToken: string) => {
    setUser(userData);
    setToken(authToken);
    localStorage.setItem('token', authToken);
    console.log('Authentication successful:', userData);
  };

  const handleAuthError = (error: string) => {
    console.error('Authentication error:', error);
  };

  const handleLogout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('token');
  };

  if (user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md text-center">
          <div className="flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mx-auto mb-4">
            <Shield className="h-8 w-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Welcome!</h2>
          <p className="text-gray-600 mb-6">You are successfully authenticated</p>
          
          <div className="bg-gray-50 rounded-lg p-4 mb-6 text-left">
            <div className="flex items-center gap-3 mb-2">
              <User className="h-5 w-5 text-gray-400" />
              <span className="font-semibold text-gray-900">{user.name}</span>
            </div>
            <p className="text-sm text-gray-600 pl-8">{user.email}</p>
          </div>

          <button
            onClick={handleLogout}
            className="w-full bg-red-600 text-white py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors flex items-center justify-center gap-2"
          >
            <LogOut className="h-5 w-5" />
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 flex items-center justify-center p-4">
      <AuthFlipCard
        onAuthSuccess={handleAuthSuccess}
        onAuthError={handleAuthError}
        apiBaseUrl="http://localhost:3001"
        initialSide="signin"
      />
    </div>
  );
}

export default LoginPage;