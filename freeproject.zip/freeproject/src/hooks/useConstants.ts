import { 
  API_CONFIG, 
  CONTACT_INFO, 
  COMPANY_INFO, 
  STATS, 
  SEO_CONFIG,
  ADMIN_CONFIG,
  UPLOAD_CONFIG,
  PAGINATION_CONFIG,
  ANIMATION_DELAYS
} from '../config/constants';

export const useConstants = () => {
  return {
    api: API_CONFIG,
    contact: CONTACT_INFO,
    company: COMPANY_INFO,
    stats: STATS,
    seo: SEO_CONFIG,
    admin: ADMIN_CONFIG,
    upload: UPLOAD_CONFIG,
    pagination: PAGINATION_CONFIG,
    animation: ANIMATION_DELAYS,
  };
};

export default useConstants;