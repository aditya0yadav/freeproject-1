import React, { useState, useEffect } from "react";
import {
  Search,
  MapPin,
  Bed,
  Bath,
  Square,
  Filter,
  SlidersHorizontal,
  Grid,
  List,
  X,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { Link } from "react-router-dom";
import { SEOHead } from "../../components/SEO/SEOHead";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Card, CardContent } from "../../components/ui/card";
import { Input } from "../../components/ui/input";
import {
  apiService,
  Property,
  PropertyFilters,
  isAuthenticated,
} from "../../services/api";
import { API_CONFIG } from "../../config/constants";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { useNavigate } from "react-router-dom";
import { Plus, Home, Wifi, Upload } from "lucide-react";

export const PublishPropertySection = ({
  isAuthenticated,
  onPropertySubmit,
  loading = false,
}) => {
  const [showPropertyModal, setShowPropertyModal] = useState(false);
  const [propertyForm, setPropertyForm] = useState({
    title: "",
    description: "",
    bedrooms: 1,
    bathrooms: 1,
    area: "",
    city: "",
    state: "",
    pincode: "",
    price: 0,
    type: "Apartment",
    status: "For Sale",
    featured: false,
    amenities: "",
    images: [],
  });

  const propertyTypes = [
    "Apartment",
    "House", 
    "Villa",
    "Townhouse",
    "Loft",
    "Penthouse",
  ];

  const states = [
    "Delhi", 
    "Haryana", 
    "Uttar Pradesh", 
    "Punjab", 
    "Rajasthan",
    "Maharashtra",
    "Karnataka",
    "Tamil Nadu",
    "Gujarat",
    "West Bengal"
  ];

  const statusOptions = [
    "For Sale",
    "For Rent", 
    "Sold",
    "Rented"
  ];

  const resetPropertyForm = () => {
    setPropertyForm({
      title: "",
      description: "",
      bedrooms: 1,
      bathrooms: 1,
      area: "",
      city: "",
      state: "",
      pincode: "",
      price: 0,
      type: "Apartment",
      status: "For Sale",
      featured: false,
      amenities: "",
      images: [],
    });
  };

  const handlePropertySubmit = async (e) => {
    e.preventDefault();
    if (onPropertySubmit) {
      // Transform the form data to match what the API expects
      const formData = new FormData();
      
      // Add all form fields
      formData.append("title", propertyForm.title);
      formData.append("description", propertyForm.description);
      formData.append("bedrooms", propertyForm.bedrooms.toString());
      formData.append("bathrooms", propertyForm.bathrooms.toString());
      formData.append("area", propertyForm.area);
      formData.append("city", propertyForm.city);
      formData.append("state", propertyForm.state);
      formData.append("pincode", propertyForm.pincode);
      formData.append("price", propertyForm.price.toString());
      formData.append("type", propertyForm.type);
      formData.append("status", propertyForm.status);
      formData.append("featured", propertyForm.featured.toString());
      
      // Handle amenities - convert comma-separated string to JSON array
      const amenitiesArray = propertyForm.amenities
        .split(",")
        .map(a => a.trim())
        .filter(a => a);
      formData.append("amenities", JSON.stringify(amenitiesArray));
      
      // Add images
      propertyForm.images.forEach((file) => {
        formData.append("images", file);
      });

      const success = await onPropertySubmit(formData);
      if (success) {
        setShowPropertyModal(false);
        resetPropertyForm();
      }
    }
  };

  const handleImageChange = (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 10) {
      alert("Maximum 10 images allowed");
      return;
    }
    setPropertyForm((prev) => ({ ...prev, images: files }));
  };

  const removeImage = (index) => {
    setPropertyForm((prev) => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index),
    }));
  };

  const handleFormChange = (key, value) => {
    setPropertyForm((prev) => ({ ...prev, [key]: value }));
  };

  // Don't render if user is not authenticated
  if (!isAuthenticated) {
    return null;
  }

  return (
    <>
      {/* Publish Property CTA Section */}
      <section className="py-8 bg-gradient-to-r from-amber-100 to-orange-100 border-b border-amber-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="shadow-lg border border-amber-200 bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
                <div className="text-center sm:text-left">
                  <h3 className="text-xl sm:text-2xl font-bold text-amber-900 mb-2">
                    Have a Property to Sell?
                  </h3>
                  <p className="text-amber-700 text-sm sm:text-base">
                    List your property with us and reach thousands of potential
                    buyers. Get started in just a few minutes!
                  </p>
                </div>
                <Button
                  onClick={() => setShowPropertyModal(true)}
                  className="bg-amber-700 hover:bg-amber-800 transform hover:scale-105 transition-all duration-300 hover:shadow-lg text-white px-6 py-3"
                >
                  <Plus className="mr-2 h-5 w-5" />
                  Publish Property
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Property Modal */}
      {showPropertyModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-amber-200 p-6 rounded-t-2xl">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-amber-900">
                  Publish Property
                </h2>
                <Button
                  variant="ghost"
                  onClick={() => {
                    setShowPropertyModal(false);
                    resetPropertyForm();
                  }}
                  className="p-2 text-amber-700 hover:bg-amber-100 rounded-full"
                >
                  <X className="h-6 w-6" />
                </Button>
              </div>
            </div>

            <form onSubmit={handlePropertySubmit} className="p-6 space-y-6">
              {/* Basic Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-amber-900 flex items-center">
                  <Home className="mr-2 h-5 w-5" />
                  Basic Information
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-amber-800 mb-2">
                      Property Title *
                    </label>
                    <Input
                      value={propertyForm.title}
                      onChange={(e) => handleFormChange("title", e.target.value)}
                      placeholder="e.g., Luxury 3BHK Apartment in Gurgaon"
                      required
                      className="border-amber-300 focus:ring-amber-600"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-amber-800 mb-2">
                      Property Type *
                    </label>
                    <select
                      value={propertyForm.type}
                      onChange={(e) => handleFormChange("type", e.target.value)}
                      required
                      className="w-full px-3 py-2 border border-amber-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-600 bg-white"
                    >
                      {propertyTypes.map((type) => (
                        <option key={type} value={type}>
                          {type}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-amber-800 mb-2">
                    Description *
                  </label>
                  <textarea
                    value={propertyForm.description}
                    onChange={(e) => handleFormChange("description", e.target.value)}
                    placeholder="Describe your property in detail..."
                    required
                    rows={4}
                    className="w-full px-3 py-2 border border-amber-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-600 bg-white resize-none"
                  />
                </div>
              </div>

              {/* Location Details */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-amber-900 flex items-center">
                  <MapPin className="mr-2 h-5 w-5" />
                  Location Details
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-amber-800 mb-2">
                      City *
                    </label>
                    <Input
                      value={propertyForm.city}
                      onChange={(e) => handleFormChange("city", e.target.value)}
                      placeholder="e.g., Gurgaon"
                      required
                      className="border-amber-300 focus:ring-amber-600"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-amber-800 mb-2">
                      State *
                    </label>
                    <select
                      value={propertyForm.state}
                      onChange={(e) => handleFormChange("state", e.target.value)}
                      required
                      className="w-full px-3 py-2 border border-amber-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-600 bg-white"
                    >
                      <option value="">Select State</option>
                      {states.map((state) => (
                        <option key={state} value={state}>
                          {state}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-amber-800 mb-2">
                      Pincode *
                    </label>
                    <Input
                      value={propertyForm.pincode}
                      onChange={(e) => handleFormChange("pincode", e.target.value)}
                      placeholder="e.g., 122001"
                      required
                      className="border-amber-300 focus:ring-amber-600"
                    />
                  </div>
                </div>
              </div>

              {/* Property Details */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-amber-900 flex items-center">
                  <Square className="mr-2 h-5 w-5" />
                  Property Details
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-amber-800 mb-2">
                      <Bed className="inline mr-1 h-4 w-4" />
                      Bedrooms *
                    </label>
                    <Input
                      type="number"
                      value={propertyForm.bedrooms}
                      onChange={(e) => handleFormChange("bedrooms", parseInt(e.target.value))}
                      placeholder="e.g., 3"
                      required
                      min="1"
                      className="border-amber-300 focus:ring-amber-600"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-amber-800 mb-2">
                      <Bath className="inline mr-1 h-4 w-4" />
                      Bathrooms *
                    </label>
                    <Input
                      type="number"
                      value={propertyForm.bathrooms}
                      onChange={(e) => handleFormChange("bathrooms", parseInt(e.target.value))}
                      placeholder="e.g., 2"
                      required
                      min="1"
                      className="border-amber-300 focus:ring-amber-600"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-amber-800 mb-2">
                      Area (sq ft) *
                    </label>
                    <Input
                      value={propertyForm.area}
                      onChange={(e) => handleFormChange("area", e.target.value)}
                      placeholder="e.g., 1500 sq ft"
                      required
                      className="border-amber-300 focus:ring-amber-600"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-amber-800 mb-2">
                      Price (₹) *
                    </label>
                    <Input
                      type="number"
                      value={propertyForm.price}
                      onChange={(e) => handleFormChange("price", parseInt(e.target.value))}
                      placeholder="e.g., 15000000"
                      required
                      className="border-amber-300 focus:ring-amber-600"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-amber-800 mb-2">
                    Status *
                  </label>
                  <select
                    value={propertyForm.status}
                    onChange={(e) => handleFormChange("status", e.target.value)}
                    required
                    className="w-full px-3 py-2 border border-amber-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-600 bg-white"
                  >
                    {statusOptions.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Amenities */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-amber-900 flex items-center">
                  <Wifi className="mr-2 h-5 w-5" />
                  Amenities
                </h3>

                <div>
                  <label className="block text-sm font-medium text-amber-800 mb-2">
                    Amenities (comma separated)
                  </label>
                  <Input
                    value={propertyForm.amenities}
                    onChange={(e) => handleFormChange("amenities", e.target.value)}
                    placeholder="e.g., Swimming Pool, Gym, Parking, Security, Garden, Elevator"
                    className="border-amber-300 focus:ring-amber-600"
                  />
                  <p className="text-xs text-amber-600 mt-1">
                    Separate multiple amenities with commas
                  </p>
                </div>
              </div>

              {/* Images */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-amber-900 flex items-center">
                  <Upload className="mr-2 h-5 w-5" />
                  Property Images
                </h3>

                <div>
                  <label className="block text-sm font-medium text-amber-800 mb-2">
                    Upload Images (Max 10) *
                  </label>
                  <Input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleImageChange}
                    className="border-amber-300 focus:ring-amber-600"
                    required
                  />
                  <p className="text-xs text-amber-600 mt-1">
                    Supported formats: JPG, PNG, WEBP. Max 5MB per image. At least one image is required.
                  </p>
                </div>

                {propertyForm.images.length > 0 && (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {propertyForm.images.map((file, index) => (
                      <div key={index} className="relative">
                        <img
                          src={URL.createObjectURL(file)}
                          alt={`Preview ${index + 1}`}
                          className="w-full h-24 object-cover rounded-lg border border-amber-200"
                        />
                        <Button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-500 hover:bg-red-600 text-white p-0"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Featured Property */}
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="featured"
                  checked={propertyForm.featured}
                  onChange={(e) => handleFormChange("featured", e.target.checked)}
                  className="w-4 h-4 text-amber-600 bg-white border-amber-300 rounded focus:ring-amber-500 focus:ring-2"
                />
                <label htmlFor="featured" className="text-sm font-medium text-amber-800">
                  Mark as Featured Property
                </label>
                <p className="text-xs text-amber-600">
                  (Featured properties get more visibility)
                </p>
              </div>

              {/* Submit Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t border-amber-200">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setShowPropertyModal(false);
                    resetPropertyForm();
                  }}
                  className="flex-1 border-amber-400 text-amber-700 hover:bg-amber-100"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={loading}
                  className="flex-1 bg-amber-700 hover:bg-amber-800 text-white disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      Publishing...
                    </>
                  ) : (
                    "Publish Property"
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
export const PropertiesPage = (): JSX.Element => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    totalProperties: 0,
    hasNext: false,
    hasPrev: false,
    limit: 9,
  });

  const [filters, setFilters] = useState<PropertyFilters>({
    search: "",
    minPrice: "",
    maxPrice: "",
    city: "",
    type: "",
    bedrooms: "",
    sortBy: "created_at",
    sortOrder: "DESC",
    page: 1,
    limit: 9,
  });

  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [showFilters, setShowFilters] = useState(false);
  const [showDialog, setShowDialog] = useState(false);
  const navigate = useNavigate();

  const handleClick = (e: React.MouseEvent) => {
    if (!isAuthenticated()) {
      e.preventDefault(); // prevent navigation
      setShowDialog(true);
    }
  };

  const handleLoginRedirect = () => {
    setShowDialog(false);
    navigate("/login");
  };

  const handlePropertySubmit = async (propertyData) => {
    try {
      setLoading(true);
      const response = await apiService.createProperty(propertyData);

      if (response.success) {
        // Refresh the properties list
        fetchProperties();
        return true;
      } else {
        setError(response.message || "Failed to publish property");
        return false;
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const priceRanges = [
    { label: "All Prices", min: "", max: "" },
    { label: "Under ₹50L", min: "", max: "5000000" },
    { label: "₹50L - ₹1Cr", min: "5000000", max: "10000000" },
    { label: "₹1Cr - ₹2Cr", min: "10000000", max: "20000000" },
    { label: "₹2Cr - ₹5Cr", min: "20000000", max: "50000000" },
    { label: "Over ₹5Cr", min: "50000000", max: "" },
  ];

  const locations = [
    "All Locations",
    "Gurgaon",
    "Delhi",
    "Noida",
    "Faridabad",
    "Ghaziabad",
  ];

  const propertyTypes = [
    "All Types",
    "House",
    "Apartment",
    "Villa",
    "Townhouse",
    "Loft",
    "Penthouse",
  ];
  const [showPropertyModal, setShowPropertyModal] = useState(false);

  const fetchProperties = async (newFilters: PropertyFilters = filters) => {
    try {
      setLoading(true);
      setError(null);

      const response = await apiService.getProperties(newFilters);

      if (response.success) {
        setProperties(response.data);
        if (response.pagination) {
          setPagination(response.pagination);
        }
      } else {
        setError(response.message || "Failed to fetch properties");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProperties();
    console.log(properties);
  }, []);

  const handleFilterChange = (
    key: keyof PropertyFilters,
    value: string | number
  ) => {
    const newFilters = { ...filters, [key]: value, page: 1 };
    setFilters(newFilters);
    fetchProperties(newFilters);
  };

  const handlePriceRangeChange = (range: { min: string; max: string }) => {
    const newFilters = {
      ...filters,
      minPrice: range.min,
      maxPrice: range.max,
      page: 1,
    };
    setFilters(newFilters);
    fetchProperties(newFilters);
  };

  const handleSearch = () => {
    fetchProperties(filters);
  };

  const handlePageChange = (page: number) => {
    const newFilters = { ...filters, page };
    setFilters(newFilters);
    fetchProperties(newFilters);
  };

  const clearFilters = () => {
    const clearedFilters: PropertyFilters = {
      search: "",
      minPrice: "",
      maxPrice: "",
      city: "",
      type: "",
      bedrooms: "",
      sortBy: "created_at",
      sortOrder: "DESC",
      page: 1,
      limit: 9,
    };
    setFilters(clearedFilters);
    fetchProperties(clearedFilters);
  };

  // Generate dynamic SEO content based on filters
  const generateSEOContent = () => {
    let title = "Properties for Sale in India - Rentwala";
    let description =
      "Browse premium properties for sale across India. Find your perfect home with Rentwala's extensive property listings.";
    let keywords =
      "properties for sale India, real estate listings, buy property India";

    if (filters.city) {
      title = `Properties for Sale in ${filters.city} - Rentwala`;
      description = `Discover premium properties for sale in ${filters.city}. Browse verified listings with photos, prices, and detailed information.`;
      keywords += `, ${filters.city} properties, ${filters.city} real estate`;
    }

    if (filters.type) {
      title = `${filters.type} for Sale in ${
        filters.city || "India"
      } - Rentwala`;
      description = `Find ${filters.type.toLowerCase()} for sale in ${
        filters.city || "India"
      }. Premium ${filters.type.toLowerCase()} listings with verified details.`;
      keywords += `, ${filters.type} for sale, ${filters.type} ${
        filters.city || "India"
      }`;
    }

    return { title, description, keywords };
  };

  const seoContent = generateSEOContent();

  const propertiesStructuredData = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: seoContent.title,
    description: seoContent.description,
    url: "https://rentwala.com/properties",
    mainEntity: {
      "@type": "ItemList",
      numberOfItems: pagination.totalProperties,
      itemListElement: properties.map((property, index) => ({
        "@type": "RealEstateListing",
        position: index + 1,
        name: property.title,
        url: `https://rentwala.com/properties/${property.id}`,
        image: property.images[0],
        price: {
          "@type": "PriceSpecification",
          price: property.price,
          priceCurrency: "INR",
        },
        address: {
          "@type": "PostalAddress",
          addressLocality: property.city,
          addressRegion: property.state,
          addressCountry: "IN",
        },
      })),
    },
    breadcrumb: {
      "@type": "BreadcrumbList",
      itemListElement: [
        {
          "@type": "ListItem",
          position: 1,
          name: "Home",
          item: "https://rentwala.com/",
        },
        {
          "@type": "ListItem",
          position: 2,
          name: "Properties",
          item: "https://rentwala.com/properties",
        },
      ],
    },
  };

  if (loading && properties.length === 0) {
    return (
      <>
        <SEOHead {...seoContent} />
        <div className="min-h-screen bg-amber-50">
          <div className="flex items-center justify-center p-4 min-h-[60vh]">
            <div className="text-center">
              <div className="w-16 sm:w-20 h-16 sm:h-20 border-4 border-amber-700 border-t-transparent rounded-full animate-spin mx-auto mb-4 sm:mb-6"></div>
              <h3 className="text-lg sm:text-xl font-semibold text-amber-900 mb-2">
                Loading Properties
              </h3>
              <p className="text-amber-700 text-sm sm:text-base">
                Please wait while we fetch the latest listings...
              </p>
            </div>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <SEOHead
        title={seoContent.title}
        description={seoContent.description}
        keywords={seoContent.keywords}
        url="https://rentwala.com/properties"
        canonical="https://rentwala.com/properties"
        structuredData={propertiesStructuredData}
      />

      <div className="min-h-screen bg-amber-50">
        <main>
          {/* Hero Section */}
          <section className="bg-white py-12 sm:py-16 lg:py-20 border-b border-amber-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center space-y-4 sm:space-y-6 animate-fade-in">
                <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-amber-900 animate-slide-up">
                  Find Your{" "}
                  <span className="text-amber-700 animate-pulse-slow">
                    Perfect Property
                  </span>
                </h1>
                <p
                  className="text-lg sm:text-xl text-amber-600 max-w-3xl mx-auto leading-relaxed animate-fade-in"
                  style={{ animationDelay: "0.2s" }}
                >
                  Discover exceptional properties that match your lifestyle and
                  budget in India's prime locations. Use our advanced filters to
                  find exactly what you're looking for.
                </p>
              </div>
            </div>
          </section>
          <PublishPropertySection
            isAuthenticated={isAuthenticated()}
            onPropertySubmit={handlePropertySubmit}
            loading={loading}
          />

          {/* Mobile Search Bar */}
          <div className="lg:hidden bg-white border-b border-amber-300 sticky top-0 z-30 shadow-md">
            <div className="px-4 py-3">
              <div className="flex space-x-2">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-amber-600" />
                  <Input
                    placeholder="Search properties..."
                    value={filters.search}
                    onChange={(e) =>
                      handleFilterChange("search", e.target.value)
                    }
                    onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                    className="pl-10 pr-4 py-2 w-full border border-amber-300 focus:ring-amber-600 focus:border-amber-600"
                  />
                </div>
                <Button
                  variant="outline"
                  onClick={() => setShowFilters(true)}
                  className="px-3 py-2 border-amber-600 text-amber-600 hover:bg-amber-100"
                >
                  <Filter className="h-4 w-4" />
                </Button>
                <Button
                  onClick={handleSearch}
                  className="px-3 py-2 bg-amber-700 hover:bg-amber-800 text-white"
                >
                  <Search className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Desktop Search and Filter Section */}
          <section className="hidden lg:block py-8 bg-white border-b border-amber-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <Card className="shadow-lg border border-amber-200 animate-scale-in">
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
                    {/* Search Input */}
                    <div className="lg:col-span-2">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-amber-600" />
                        <Input
                          placeholder="Search properties..."
                          value={filters.search}
                          onChange={(e) =>
                            handleFilterChange("search", e.target.value)
                          }
                          onKeyPress={(e) =>
                            e.key === "Enter" && handleSearch()
                          }
                          className="pl-10 transition-all duration-300 focus:scale-105 border border-amber-300 focus:ring-amber-600 focus:border-amber-600"
                        />
                      </div>
                    </div>

                    {/* Price Range Filter */}
                    <div>
                      <select
                        value={`${filters.minPrice}-${filters.maxPrice}`}
                        onChange={(e) => {
                          const [min, max] = e.target.value.split("-");
                          handlePriceRangeChange({ min, max });
                        }}
                        className="w-full px-3 py-2 border border-amber-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent transition-all duration-300 hover:shadow-md bg-white"
                      >
                        {priceRanges.map((range, index) => (
                          <option
                            key={index}
                            value={`${range.min}-${range.max}`}
                          >
                            {range.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Location Filter */}
                    <div>
                      <select
                        value={filters.city}
                        onChange={(e) =>
                          handleFilterChange("city", e.target.value)
                        }
                        className="w-full px-3 py-2 border border-amber-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-600 transition-all duration-300 hover:shadow-md bg-white"
                      >
                        {locations.map((location) => (
                          <option
                            key={location}
                            value={location === "All Locations" ? "" : location}
                          >
                            {location}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Property Type Filter */}
                    <div>
                      <select
                        value={filters.type}
                        onChange={(e) =>
                          handleFilterChange("type", e.target.value)
                        }
                        className="w-full px-3 py-2 border border-amber-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-600 transition-all duration-300 hover:shadow-md bg-white"
                      >
                        {propertyTypes.map((type) => (
                          <option
                            key={type}
                            value={type === "All Types" ? "" : type}
                          >
                            {type}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Search Button */}
                    <div>
                      <Button
                        onClick={handleSearch}
                        className="w-full bg-amber-700 hover:bg-amber-800 transform hover:scale-105 transition-all duration-300 hover:shadow-lg text-white"
                        disabled={loading}
                      >
                        <Filter className="mr-2 h-4 w-4" />
                        {loading ? "Searching..." : "Search"}
                      </Button>
                    </div>
                  </div>

                  {/* Additional Filters */}
                  <div
                    className="mt-4 pt-4 border-t border-amber-200 animate-slide-up"
                    style={{ animationDelay: "0.3s" }}
                  >
                    <div className="flex flex-wrap gap-4 items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <SlidersHorizontal className="h-4 w-4 text-amber-600" />
                          <span className="text-sm text-amber-700">
                            Bedrooms:
                          </span>
                        </div>
                        <select
                          value={filters.bedrooms}
                          onChange={(e) =>
                            handleFilterChange("bedrooms", e.target.value)
                          }
                          className="px-3 py-1 border border-amber-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-amber-600 transition-all duration-300 hover:shadow-md bg-white"
                        >
                          <option value="">Any</option>
                          <option value="1">1+</option>
                          <option value="2">2+</option>
                          <option value="3">3+</option>
                          <option value="4">4+</option>
                          <option value="5">5+</option>
                        </select>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={clearFilters}
                          className="text-amber-700 hover:text-amber-900 border border-amber-400 hover:bg-amber-100"
                        >
                          Clear Filters
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </section>

          {showFilters && (
            <div className="lg:hidden fixed inset-0 bg-black/50 z-50 flex items-end">
              <div className="bg-white w-full rounded-t-2xl p-6 space-y-6 animate-slide-up max-h-[80vh] overflow-y-auto">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-amber-900">
                    Filters
                  </h3>
                  <Button
                    variant="ghost"
                    onClick={() => setShowFilters(false)}
                    className="p-2 text-amber-700 hover:bg-amber-100"
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-amber-800 mb-2">
                      Price Range
                    </label>
                    <select
                      value={`${filters.minPrice}-${filters.maxPrice}`}
                      onChange={(e) => {
                        const [min, max] = e.target.value.split("-");
                        handlePriceRangeChange({ min, max });
                      }}
                      className="w-full px-3 py-2 border border-amber-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-600 bg-white"
                    >
                      {priceRanges.map((range, index) => (
                        <option key={index} value={`${range.min}-${range.max}`}>
                          {range.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-amber-800 mb-2">
                      Location
                    </label>
                    <select
                      value={filters.city}
                      onChange={(e) =>
                        handleFilterChange("city", e.target.value)
                      }
                      className="w-full px-3 py-2 border border-amber-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-600 bg-white"
                    >
                      {locations.map((location) => (
                        <option
                          key={location}
                          value={location === "All Locations" ? "" : location}
                        >
                          {location}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-amber-800 mb-2">
                      Property Type
                    </label>
                    <select
                      value={filters.type}
                      onChange={(e) =>
                        handleFilterChange("type", e.target.value)
                      }
                      className="w-full px-3 py-2 border border-amber-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-600 bg-white"
                    >
                      {propertyTypes.map((type) => (
                        <option
                          key={type}
                          value={type === "All Types" ? "" : type}
                        >
                          {type}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-amber-800 mb-2">
                      Bedrooms
                    </label>
                    <select
                      value={filters.bedrooms}
                      onChange={(e) =>
                        handleFilterChange("bedrooms", e.target.value)
                      }
                      className="w-full px-3 py-2 border border-amber-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-600 bg-white"
                    >
                      <option value="">Any</option>
                      <option value="1">1+</option>
                      <option value="2">2+</option>
                      <option value="3">3+</option>
                      <option value="4">4+</option>
                      <option value="5">5+</option>
                    </select>
                  </div>
                </div>

                <div className="flex space-x-3 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => {
                      clearFilters();
                      setShowFilters(false);
                    }}
                    className="flex-1 border-amber-400 text-amber-700 hover:bg-amber-100"
                  >
                    Clear All
                  </Button>
                  <Button
                    onClick={() => {
                      handleSearch();
                      setShowFilters(false);
                    }}
                    className="flex-1 bg-amber-700 hover:bg-amber-800 text-white"
                    disabled={loading}
                  >
                    {loading ? "Searching..." : "Apply Filters"}
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Error State */}
          {error && (
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
              <div className="bg-red-50 border border-red-300 rounded-lg p-6 text-center">
                <h3 className="text-lg font-semibold text-red-800 mb-2">
                  Error Loading Properties
                </h3>
                <p className="text-red-700 mb-4">{error}</p>
                <Button
                  onClick={() => fetchProperties()}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  Try Again
                </Button>
              </div>
            </div>
          )}

          {/* Properties Grid */}
          <section className="py-6 sm:py-8 lg:py-12 bg-amber-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              {/* Header with View Toggle */}
              <div className="flex items-center justify-between sm:justify-end space-x-4">
                {/* Publish Property Button */}
                {isAuthenticated() && (
                  <Button
                    onClick={() => setShowPropertyModal(true)}
                    className="bg-amber-700 hover:bg-amber-800 text-white px-4 py-2"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Publish Property
                  </Button>
                )}

                {/* View Mode Toggle - Hidden on mobile */}
                <div className="hidden sm:flex items-center space-x-2 bg-white rounded-lg p-1 border border-amber-200 shadow-md">
                  <Button
                    variant={viewMode === "grid" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("grid")}
                    className={
                      viewMode === "grid"
                        ? "bg-amber-700 text-white hover:bg-amber-800"
                        : "text-amber-700 hover:bg-amber-100"
                    }
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("list")}
                    className={
                      viewMode === "list"
                        ? "bg-amber-700 text-white hover:bg-amber-800"
                        : "text-amber-700 hover:bg-amber-100"
                    }
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>

                <div className="flex items-center justify-between sm:justify-end space-x-4">
                  {/* View Mode Toggle - Hidden on mobile */}
                  <div className="hidden sm:flex items-center space-x-2 bg-white rounded-lg p-1 border border-amber-200 shadow-md">
                    <Button
                      variant={viewMode === "grid" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setViewMode("grid")}
                      className={
                        viewMode === "grid"
                          ? "bg-amber-700 text-white hover:bg-amber-800"
                          : "text-amber-700 hover:bg-amber-100"
                      }
                    >
                      <Grid className="h-4 w-4" />
                    </Button>
                    <Button
                      variant={viewMode === "list" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setViewMode("list")}
                      className={
                        viewMode === "list"
                          ? "bg-amber-700 text-white hover:bg-amber-800"
                          : "text-amber-700 hover:bg-amber-100"
                      }
                    >
                      <List className="h-4 w-4" />
                    </Button>
                  </div>

                  {/* Sort Dropdown */}
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-amber-700 hidden sm:inline">
                      Sort by:
                    </span>
                    <select
                      value={`${filters.sortBy}-${filters.sortOrder}`}
                      onChange={(e) => {
                        const [sortBy, sortOrder] = e.target.value.split("-");
                        handleFilterChange("sortBy", sortBy);
                        handleFilterChange("sortOrder", sortOrder);
                      }}
                      className="px-3 py-1 border border-amber-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-amber-600 transition-all duration-300 hover:shadow-md bg-white"
                    >
                      <option value="price-ASC">Price: Low to High</option>
                      <option value="price-DESC">Price: High to Low</option>
                      <option value="created_at-DESC">Newest First</option>
                      <option value="bedrooms-DESC">Most Bedrooms</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Properties Grid/List */}
              {properties.length === 0 && !loading ? (
                <div className="text-center py-12">
                  <div className="w-24 h-24 bg-amber-200 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Search className="h-12 w-12 text-amber-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-amber-900 mb-2">
                    No Properties Found
                  </h3>
                  <p className="text-amber-700 mb-6">
                    Try adjusting your search criteria or filters.
                  </p>
                  <Button
                    onClick={clearFilters}
                    variant="outline"
                    className="border-amber-400 text-amber-700 hover:bg-amber-100"
                  >
                    Clear All Filters
                  </Button>
                </div>
              ) : (
                <>
                  <div
                    className={`grid gap-4 sm:gap-6 lg:gap-8 ${
                      viewMode === "grid"
                        ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"
                        : "grid-cols-1"
                    }`}
                  >
                    {properties.map((property, index) => (
                      <Card
                        key={property.id}
                        className={`group hover:shadow-xl transition-all duration-500 border-0 shadow-lg overflow-hidden hover:-translate-y-1 animate-scale-in bg-white ${
                          viewMode === "list" ? "sm:flex sm:flex-row" : ""
                        }`}
                        style={{ animationDelay: `${index * 0.1}s` }}
                      >
                        <div
                          className={`relative overflow-hidden ${
                            viewMode === "list"
                              ? "sm:w-80 sm:flex-shrink-0"
                              : ""
                          }`}
                        >
                          <img
                            src={
                              property.images && property.images.length > 0
                                ? property.images[0].startsWith("http")
                                  ? property.images[0]
                                  : `${API_CONFIG.IMG}${property.images[0]}`
                                : "https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=800"
                            }
                            alt={property.title}
                            className={`w-full object-cover group-hover:scale-110 transition-transform duration-500 ${
                              viewMode === "list"
                                ? "h-48 sm:h-full"
                                : "h-48 sm:h-56 lg:h-64"
                            }`}
                            loading="lazy"
                          />

                          <div className="absolute top-3 left-3 flex flex-wrap gap-2">
                            <Badge className="bg-amber-700 text-white text-xs animate-bounce-in">
                              {property.type}
                            </Badge>
                            {property.featured && (
                              <Badge
                                variant="secondary"
                                className="bg-white/90 text-amber-900 text-xs animate-bounce-in"
                                style={{ animationDelay: "0.2s" }}
                              >
                                Featured
                              </Badge>
                            )}
                          </div>
                          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                        </div>

                        <CardContent
                          className={`p-4 sm:p-6 space-y-3 sm:space-y-4 flex-1 ${
                            viewMode === "list"
                              ? "flex flex-col justify-between"
                              : ""
                          }`}
                        >
                          <div className="space-y-2">
                            <h3 className="text-lg sm:text-xl font-semibold text-amber-900 group-hover:text-amber-700 transition-colors duration-300 line-clamp-2">
                              {property.title}
                            </h3>
                            <div className="flex items-center text-amber-700">
                              <MapPin className="h-4 w-4 mr-1 group-hover:text-amber-600 transition-colors duration-300 flex-shrink-0" />
                              <span className="text-sm">
                                {property.location}
                              </span>
                            </div>
                            <p className="text-amber-600 text-sm line-clamp-2 sm:line-clamp-3">
                              {property.description}
                            </p>
                          </div>

                          <div className="grid grid-cols-3 gap-4 text-sm text-amber-700">
                            <div className="flex items-center justify-center p-2 bg-amber-100 rounded-lg group-hover:text-amber-800 transition-colors duration-300">
                              <Bed className="h-4 w-4 mr-1" />
                              <span className="font-medium">
                                {property.bedrooms}
                              </span>
                            </div>
                            <div className="flex items-center justify-center p-2 bg-amber-100 rounded-lg group-hover:text-amber-800 transition-colors duration-300">
                              <Bath className="h-4 w-4 mr-1" />
                              <span className="font-medium">
                                {property.bathrooms}
                              </span>
                            </div>
                            <div className="flex items-center justify-center p-2 bg-amber-100 rounded-lg group-hover:text-amber-800 transition-colors duration-300">
                              <Square className="h-4 w-4 mr-1" />
                              <span className="font-medium text-xs">
                                {property.area}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center justify-between pt-3 sm:pt-4 border-t border-amber-200">
                            <div className="space-y-1">
                              <p className="text-xs text-amber-600">Price</p>
                              <p className="text-xl sm:text-2xl font-bold text-amber-800 animate-pulse-slow">
                                {property.priceFormatted}
                              </p>
                            </div>
                            <>
                              {isAuthenticated() ? (
                                <a href={`/properties/${property.id}`}>
                                  <Button className="bg-amber-700 hover:bg-amber-800 transform hover:scale-105 transition-all duration-300 hover:shadow-lg text-sm sm:text-base px-4 sm:px-6 text-white">
                                    View Details
                                  </Button>
                                </a>
                              ) : (
                                <Button
                                  onClick={handleClick}
                                  className="bg-amber-700 hover:bg-amber-800 transform hover:scale-105 transition-all duration-300 hover:shadow-lg text-sm sm:text-base px-4 sm:px-6 text-white"
                                >
                                  View Details
                                </Button>
                              )}

                              {showDialog && (
                                <div className="fixed inset-0 flex items-center justify-center bg-white/50 z-50">
                                  <div className="bg-white rounded-2xl shadow-lg p-6 w-80">
                                    <h2 className="text-lg font-semibold mb-2">
                                      Login Required
                                    </h2>
                                    <p className="text-sm text-gray-600 mb-4">
                                      You need to login before viewing property
                                      details.
                                    </p>
                                    <div className="flex justify-end gap-2">
                                      <Button
                                        variant="outline"
                                        onClick={() => setShowDialog(false)}
                                      >
                                        Cancel
                                      </Button>
                                      <Button
                                        onClick={() => navigate("/login")}
                                        className="bg-amber-700 text-white"
                                      >
                                        Go to Login
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              )}
                            </>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {/* Pagination */}
                  {pagination.totalPages > 1 && (
                    <nav
                      className="flex items-center justify-center space-x-2 mt-8 sm:mt-12"
                      aria-label="Pagination"
                    >
                      <Button
                        variant="outline"
                        onClick={() =>
                          handlePageChange(pagination.currentPage - 1)
                        }
                        disabled={!pagination.hasPrev || loading}
                        className="p-2 border-amber-300 text-amber-700 hover:bg-amber-100"
                        aria-label="Previous page"
                      >
                        <ChevronLeft className="h-4 w-4" />
                      </Button>

                      <div className="flex items-center space-x-1">
                        {Array.from(
                          { length: Math.min(5, pagination.totalPages) },
                          (_, i) => {
                            let pageNumber;
                            if (pagination.totalPages <= 5) {
                              pageNumber = i + 1;
                            } else if (pagination.currentPage <= 3) {
                              pageNumber = i + 1;
                            } else if (
                              pagination.currentPage >=
                              pagination.totalPages - 2
                            ) {
                              pageNumber = pagination.totalPages - 4 + i;
                            } else {
                              pageNumber = pagination.currentPage - 2 + i;
                            }

                            return (
                              <Button
                                key={pageNumber}
                                variant={
                                  pageNumber === pagination.currentPage
                                    ? "default"
                                    : "outline"
                                }
                                onClick={() => handlePageChange(pageNumber)}
                                disabled={loading}
                                className={`w-10 h-10 p-0 ${
                                  pageNumber === pagination.currentPage
                                    ? "bg-amber-700 text-white hover:bg-amber-800"
                                    : "border-amber-300 text-amber-700 hover:bg-amber-100"
                                }`}
                                aria-label={`Page ${pageNumber}`}
                                aria-current={
                                  pageNumber === pagination.currentPage
                                    ? "page"
                                    : undefined
                                }
                              >
                                {pageNumber}
                              </Button>
                            );
                          }
                        )}
                      </div>

                      <Button
                        variant="outline"
                        onClick={() =>
                          handlePageChange(pagination.currentPage + 1)
                        }
                        disabled={!pagination.hasNext || loading}
                        className="p-2 border-amber-300 text-amber-700 hover:bg-amber-100"
                        aria-label="Next page"
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </nav>
                  )}
                </>
              )}
            </div>
          </section>
        </main>
      </div>
    </>
  );
};
