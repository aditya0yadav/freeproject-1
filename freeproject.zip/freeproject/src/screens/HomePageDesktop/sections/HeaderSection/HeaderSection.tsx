import { Menu, X } from "lucide-react";
import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "../../../../components/ui/button";
import useSiteConfig from "../../../../hooks/useSiteConfig";
import { API_CONFIG } from "../../../../config/constants";
import { isAuthenticated } from "../../../../services/api";

export const HeaderSection = (): JSX.Element => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showBanner, setShowBanner] = useState(true);
  const location = useLocation();
  const config = useSiteConfig();

  const navItems = [
    { name: "Home", path: "/" },
    { name: "About Us", path: "/about" },
    { name: "Services", path: "/services" },
  ];

  const isActive = (path: string) => location.pathname === path;

  const authenticated = isAuthenticated();

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-[#7B3F00] shadow-sm">
      {/* Notification Banner */}
      {showBanner && (
        <div className="bg-[#7B3F00] text-white py-3 px-4 animate-slide-in">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-4 text-sm md:text-base">
              <span className="animate-pulse-slow">
                🏠 Discover Your Dream Property with {config.company.name}
              </span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/20 p-1 transition-all duration-300 hover:rotate-90"
              onClick={() => setShowBanner(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Main Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 group">
            <img
              src={`${API_CONFIG.IMG}/uploads/logo1.png`}
              alt="Logo"
              className="h-10 w-auto object-contain"
            />

            <span className="text-xl font-bold text-[#7B3F00] group-hover:text-[#A0522D] transition-colors duration-300">
              {config.company.name}
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navItems.map((item, index) => (
              <Link
                key={item.name}
                to={item.path}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-all duration-300 transform hover:scale-105 ${
                  isActive(item.path)
                    ? "bg-[#D2B48C] text-[#7B3F00] shadow-md"
                    : "text-[#7B3F00] hover:text-white hover:bg-[#A0522D]"
                }`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {item.name}
              </Link>
            ))}
            {/* Authenticated: Welcome, else Login/Signup */}
            {authenticated ? (
              <span className="ml-4 text-[#7B3F00] font-semibold">Welcome!</span>
            ) : (
              <Link to="/login">
                <Button className="ml-2 bg-[#7B3F00] text-white hover:bg-[#A0522D] transition-all duration-300 shadow-md">
                  Login / Signup
                </Button>
              </Link>
            )}
          </nav>

          {/* Contact Button & Mobile Menu */}
          <div className="flex items-center space-x-4">
            <Link to="/contact">
              <Button className="hidden md:inline-flex bg-[#D2B48C] text-[#7B3F00] hover:bg-[#A0522D] hover:text-white transform hover:scale-105 transition-all duration-300 hover:shadow-lg">
                Contact Us
              </Button>
            </Link>

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden transition-all duration-300 hover:scale-110"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-[#7B3F00] animate-slide-up bg-white">
            <nav className="flex flex-col space-y-2">
              {navItems.map((item, index) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`px-3 py-2 rounded-md text-base font-medium transition-all duration-300 transform hover:translate-x-2 ${
                    isActive(item.path)
                      ? "bg-[#D2B48C] text-[#7B3F00]"
                      : "text-[#7B3F00] hover:text-white hover:bg-[#A0522D]"
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  {item.name}
                </Link>
              ))}
              {authenticated ? (
                <span className="mt-4 text-[#7B3F00] font-semibold text-center">Welcome!</span>
              ) : (
                <Link to="/login">
                  <Button className="mt-4 bg-[#7B3F00] text-white hover:bg-[#A0522D] transition-all duration-300 w-full">
                    Login / Signup
                  </Button>
                </Link>
              )}
              <Link to="/contact">
                <Button className="mt-2 bg-[#D2B48C] text-[#7B3F00] hover:bg-[#A0522D] hover:text-white transition-all duration-300 w-full">
                  Contact Us
                </Button>
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};
