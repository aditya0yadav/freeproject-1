import React from "react";
import { Mail, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { Input } from "../../../../components/ui/input";
import { API_CONFIG } from "../../../../config/constants";

export const FAQSection = (): JSX.Element => {
  const footerNavigation = {
    home: {
      title: "Home",
      links: [
        { name: "Hero Section", path: "/#hero" },
        { name: "Features", path: "/#features" },
        { name: "Properties", path: "/properties" },
        { name: "Testimonials", path: "/#testimonials" },
        { name: "FAQ's", path: "/#faq" },
      ],
    },
    aboutUs: {
      title: "About Us",
      links: [
        { name: "Our Story", path: "/about#story" },
        { name: "Our Works", path: "/about#works" },
        { name: "How It Works", path: "/about#how-it-works" },
        { name: "Our Team", path: "/about#team" },
        { name: "Our Clients", path: "/about#clients" },
      ],
    },
    properties: {
      title: "Properties",
      links: [
        { name: "Portfolio", path: "/properties#portfolio" },
        { name: "Categories", path: "/properties#categories" },
      ],
    },
    services: {
      title: "Services",
      links: [
        { name: "Property Search", path: "/services#property-search" },
        { name: "Strategic Marketing", path: "/services#marketing" },
        { name: "Negotiation Support", path: "/services#negotiation" },
        { name: "Legal Assistance", path: "/services#legal" },
        { name: "Property Management", path: "/services#management" },
      ],
    },
    contactUs: {
      title: "Contact Us",
      links: [
        { name: "Contact Form", path: "/contact#form" },
        { name: "Our Offices", path: "/contact#offices" },
      ],
    },
  };

  const socialIcons = [
    { Icon: Facebook, href: "#" },
    { Icon: Twitter, href: "#" },
    { Icon: Instagram, href: "#" },
    { Icon: Linkedin, href: "#" },
  ];

  return (
  <div className="bg-[#fff8f0]">
      {/* CTA Section */}
      <section className="py-20 bg-[#7B3F00] relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-[#7B3F00] to-[#A0522D]"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 animate-fade-in">
              <h2 className="text-3xl md:text-4xl font-bold text-white">
                Start Your Real Estate Journey Today
              </h2>
              <p className="text-xl text-[#fff8f0] leading-relaxed">
                Your dream property is just a click away. Whether you're looking
                for a new home, a strategic investment, or expert real estate
                advice, Rentwala is here to assist you every step of the way
                across India's prime locations.
              </p>
            </div>
            <div
              className="flex justify-center lg:justify-end animate-bounce-in"
              style={{ animationDelay: "0.3s" }}
            >
              <Link to="/properties">
                <Button
                  size="lg"
                  variant="secondary"
                  className="bg-[#fff8f0] text-[#7B3F00] hover:bg-[#D2B48C]/40 transform hover:scale-105 transition-all duration-300 hover:shadow-lg border-0"
                >
                  Explore Properties
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Background Decorations */}
        <div className="absolute top-10 right-10 w-32 h-32 bg-[#fff8f0]/10 rounded-full animate-float"></div>
        <div
          className="absolute bottom-10 left-10 w-40 h-40 bg-[#fff8f0]/5 rounded-full animate-float"
          style={{ animationDelay: "1s" }}
        ></div>
      </section>

      {/* Footer Section */}
  <footer className="bg-[#7B3F00] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid lg:grid-cols-6 gap-8">
            {/* Logo and Newsletter */}
            <div className="lg:col-span-2 space-y-6 animate-fade-in">
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center transform hover:scale-110 transition-transform duration-300 bg-[#fff8f0]">
                  <img
                    src={`${API_CONFIG.IMG}/uploads/logo1.png`}
                    alt="Logo"
                    className="h-10 w-auto object-contain"
                  />
                </div>
                <span className="text-xl font-bold text-[#fff8f0]">Rentwala</span>
              </div>

              <Card className="bg-[#A0522D] border-[#D2B48C] hover:bg-[#7B3F00]/90 transition-colors duration-300">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Mail className="h-5 w-5 text-[#fff8f0]" />
                    <Input
                      placeholder="Enter Your Email"
                      className="bg-transparent border-0 text-[#fff8f0] placeholder:text-[#D2B48C] focus-visible:ring-0"
                    />
                    <Button
                      size="sm"
                      className="bg-[#fff8f0] text-[#7B3F00] hover:bg-[#D2B48C]/40 transform hover:scale-105 transition-all duration-300 border-0"
                    >
                      Subscribe
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Navigation Links */}
            <div className="lg:col-span-4 grid grid-cols-2 md:grid-cols-5 gap-8">
              {Object.entries(footerNavigation).map(([key, section], index) => (
                <div
                  key={key}
                  className="space-y-4 animate-slide-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <h3 className="font-semibold text-[#D2B48C]">
                    {section.title}
                  </h3>
                  <ul className="space-y-2">
                    {section.links.map((link, linkIndex) => (
                      <li key={linkIndex}>
                        <Link
                          to={link.path}
                          className="text-[#fff8f0]/80 hover:text-[#fff8f0] transition-colors duration-300 text-sm transform hover:translate-x-1 inline-block"
                        >
                          {link.name}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Bottom */}
  <div className="border-t border-[#A0522D]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
              <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-6 space-y-2 sm:space-y-0 animate-fade-in">
                <p className="text-[#D2B48C] text-sm">
                  © 2024 Rentwala. All Rights Reserved.
                </p>
                <Link
                  to="/terms"
                  className="text-[#D2B48C] hover:text-[#fff8f0] text-sm transition-colors duration-300"
                >
                  Terms & Conditions
                </Link>
              </div>

              <div
                className="flex items-center space-x-4 animate-bounce-in"
                style={{ animationDelay: "0.5s" }}
              >
                {socialIcons.map(({ Icon, href }, index) => (
                  <a
                    key={index}
                    href={href}
                    className="w-10 h-10 bg-[#A0522D] rounded-full flex items-center justify-center hover:bg-[#fff8f0] hover:text-[#7B3F00] transition-all duration-300 transform hover:scale-110"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <Icon className="h-5 w-5" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};