export { FeaturedPropertiesSection } from "./FeaturedPropertiesSection";
