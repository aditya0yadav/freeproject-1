import React, { useState, useEffect } from "react";
import { MapPin, Bed, Bath, Square, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { Badge } from "../../../../components/ui/badge";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { apiService, Property } from "../../../../services/api";
import { API_CONFIG } from "../../../../config/constants";
// API Configuration
// export const API_CONFIG = {
//   BASE_URL: 'https://property-rent-wala.onrender.com/api',
//   TIMEOUT: 10000, 
//   RETRY_ATTEMPTS: 3,
//   IMG : 'https://property-rent-wala.onrender.com'
// } as const;

export const CONTACT_INFO = {
  PHONE: {
    PRIMARY: '818181-1678',
    DISPLAY: '+91 818181-1678',
    FORMATTED: '+91 81818-11678',
  },
  EMAIL: {
    PRIMARY: 'property.rentwala@gmail.com',
  },
  ADDRESS: {
    HEADQUARTERS: {
      STREET: 'DLF Cyber City, Sector 25',
      CITY: 'Gurgaon',
      STATE: 'Haryana',
      PINCODE: '122002',
      FULL: 'DLF Cyber City, Sector 25, Gurgaon, Haryana 122002',
    },
  },
  SOCIAL: {
    FACEBOOK: 'https://facebook.com/rentwala',
    TWITTER: 'https://twitter.com/rentwala',
    INSTAGRAM: 'https://instagram.com/rentwala',
    LINKEDIN: 'https://linkedin.com/company/rentwala',
  },
  BUSINESS_HOURS: {
    WEEKDAYS: 'Mon - Fri: 9:00 AM - 7:00 PM',
    WEEKENDS: 'Sat - Sun: 10:00 AM - 5:00 PM',
  },
} as const;

// Company Information
export const COMPANY_INFO = {
  NAME: 'Rentwala',
  TAGLINE: 'Your Dream Property Awaits',
  DESCRIPTION: 'India\'s leading real estate platform dedicated to helping you find your dream property across major Indian cities.',
  ESTABLISHED: '2012',
  EXPERIENCE: '12+',
  LOCATIONS: ['Gurgaon', 'Delhi', 'Noida', 'Faridabad', 'Ghaziabad'],
} as const;

// Statistics
export const STATS = {
  PROPERTIES_SOLD: '25,000+',
  HAPPY_CLIENTS: '15,000+',
  YEARS_EXPERIENCE: '12+',
  SUCCESS_RATE: '99%',
} as const;

// SEO Configuration
export const SEO_CONFIG = {
  DEFAULT_TITLE: 'Rentwala - Find Your Dream Property in India | Real Estate Platform',
  DEFAULT_DESCRIPTION: 'Discover your perfect property with Rentwala, India\'s leading real estate platform. Browse 25,000+ properties across Delhi-NCR, Gurgaon, Noida. Expert agents, transparent pricing, 12+ years experience.',
  DEFAULT_KEYWORDS: 'real estate India, property for sale, buy property Delhi, Gurgaon properties, Noida real estate, property investment, dream home India, real estate agent',
  SITE_URL: 'https://rentwala.com',
  OG_IMAGE: 'https://rentwala.com/og-image.jpg',
  TWITTER_HANDLE: '@rentwala',
} as const;

// Admin Configuration
export const ADMIN_CONFIG = {
  DEFAULT_CREDENTIALS: {
    USERNAME: 'admin',
    PASSWORD: 'admin123',
  },
  SESSION_TIMEOUT: 24 * 60 * 60 * 1000, // 24 hours
} as const;

// File Upload Configuration
export const UPLOAD_CONFIG = {
  MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB
  ALLOWED_IMAGE_TYPES: ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'],
  MAX_IMAGES_PER_PROPERTY: 10,
} as const;

// Pagination Configuration
export const PAGINATION_CONFIG = {
  DEFAULT_PAGE_SIZE: 9,
  MAX_PAGE_SIZE: 50,
  MOBILE_PAGE_SIZE: 6,
} as const;

// Animation Delays
export const ANIMATION_DELAYS = {
  STAGGER: 0.1, // seconds between staggered animations
  FADE_IN: 0.2,
  SLIDE_UP: 0.3,
  BOUNCE_IN: 0.4,
} as const;

export const FeaturedPropertiesSection = (): JSX.Element => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchFeaturedProperties = async () => {
      try {
        setLoading(true);
        setError(null);
        const response = await apiService.getProperties({
          featured: "true",
          limit: 3,
        });
        if (response.success) {
          setProperties(response.data);
        } else {
          setError("Failed to load featured properties");
        }
      } catch (error) {
        console.error("Error fetching featured properties:", error);
        setError("Failed to load featured properties");
      } finally {
        setLoading(false);
      }
    };

    fetchFeaturedProperties();
  }, []);

  const getImageUrl = (property: Property): string => {
    if (property.images && property.images.length > 0) {
      const imageUrl = property.images[0];
      return imageUrl.startsWith("http") 
        ? imageUrl 
        : `${API_CONFIG.IMG}${imageUrl}`;
    }
    return "https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=800";
  };

  if (loading) {
    return (
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Featured Properties
            </h2>
            <p className="text-lg text-gray-600">
              Loading our best properties...
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="bg-white rounded-lg shadow-lg overflow-hidden animate-pulse"
              >
                <div className="h-64 bg-gray-300"></div>
                <div className="p-6 space-y-4">
                  <div className="h-4 bg-gray-300 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-300 rounded w-1/2"></div>
                  <div className="h-4 bg-gray-300 rounded w-full"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Featured Properties
            </h2>
            <p className="text-lg text-red-600">{error}</p>
            <Button 
              onClick={() => window.location.reload()} 
              className="mt-4"
            >
              Try Again
            </Button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-12 space-y-4 lg:space-y-0">
          <div className="space-y-4 animate-fade-in">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
              Featured Properties
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl">
              Explore our handpicked selection of featured properties. Each
              listing offers a glimpse into exceptional homes and investments
              available through Rentwala.
            </p>
          </div>
          <Link to="/properties">
            <Button
              variant="outline"
              className="group transform hover:scale-105 transition-all duration-300 hover:shadow-lg"
            >
              View All Properties
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-2 transition-transform duration-300" />
            </Button>
          </Link>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {properties.map((property, index) => (
            <Card
              key={property.id}
              className="group hover:shadow-xl transition-all duration-500 border-0 shadow-lg overflow-hidden hover:-translate-y-2 animate-scale-in"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <div className="relative overflow-hidden">
                <img
                  src={getImageUrl(property)}
                  alt={property.title}
                  className="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  loading="lazy"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=800";
                  }}
                />

                <div className="absolute top-3 left-3 flex flex-wrap gap-2">
                  <Badge className="bg-primary-600 text-white text-xs animate-bounce-in">
                    {property.type}
                  </Badge>
                  {property.featured && (
                    <Badge
                      variant="secondary"
                      className="bg-white/90 text-gray-900 text-xs animate-bounce-in"
                      style={{ animationDelay: "0.2s" }}
                    >
                      Featured
                    </Badge>
                  )}
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>

              <CardContent className="p-6 space-y-4">
                <div className="space-y-2">
                  <h3 className="text-xl font-semibold text-gray-900 group-hover:text-primary-600 transition-colors duration-300">
                    {property.title}
                  </h3>
                  <div className="flex items-center text-gray-600">
                    <MapPin className="h-4 w-4 mr-1 group-hover:text-primary-600 transition-colors duration-300" />
                    <span className="text-sm">{property.location}</span>
                  </div>
                  <p className="text-gray-600 text-sm line-clamp-2">
                    {property.description}
                  </p>
                </div>

                <div className="flex items-center justify-between text-sm text-gray-600">
                  <div className="flex items-center group-hover:text-primary-600 transition-colors duration-300">
                    <Bed className="h-4 w-4 mr-1" />
                    <span>{property.bedrooms}</span>
                  </div>
                  <div className="flex items-center group-hover:text-primary-600 transition-colors duration-300">
                    <Bath className="h-4 w-4 mr-1" />
                    <span>{property.bathrooms}</span>
                  </div>
                  <div className="flex items-center group-hover:text-primary-600 transition-colors duration-300">
                    <Square className="h-4 w-4 mr-1" />
                    <span>{property.area}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                  <div className="space-y-1">
                    <p className="text-sm text-gray-600">Price</p>
                    <p className="text-2xl font-bold text-primary-600 animate-pulse-slow">
                      {property.priceFormatted}
                    </p>
                  </div>
                  <Link to={`/properties/${property.id}`}>
                    <Button className="bg-primary-600 hover:bg-primary-700 transform hover:scale-105 transition-all duration-300 hover:shadow-lg">
                      View Details
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};