import React, { useState, useEffect } from "react";
import { Star, Quote } from "lucide-react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { apiService, Testimonial } from "../../../../services/api";

export const ClientTestimonialsSection = (): JSX.Element => {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTestimonials = async () => {
      try {
        const response = await apiService.getTestimonials(true);
        if (response.success) {
          setTestimonials(response.data.slice(0, 3)); // Show only first 3
        }
      } catch (error) {
        console.error('Error fetching testimonials:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTestimonials();
  }, []);

  if (loading) {
    return (
      <section className="py-20 bg-[#fff8f0]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#7B3F00] mb-4">What Our Clients Say</h2>
            <p className="text-lg text-[#A0522D]">Loading testimonials...</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-lg shadow-lg p-6 animate-pulse">
                <div className="space-y-4">
                  <div className="h-4 bg-[#D2B48C]/40 rounded w-3/4"></div>
                  <div className="h-4 bg-[#D2B48C]/40 rounded w-full"></div>
                  <div className="h-4 bg-[#D2B48C]/40 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-[#fff8f0]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-12 space-y-4 lg:space-y-0">
          <div className="space-y-4 animate-fade-in">
            <h2 className="text-3xl md:text-4xl font-bold text-[#7B3F00]">
              What Our Clients Say
            </h2>
            <p className="text-lg text-[#A0522D] max-w-2xl">
              Read the success stories and heartfelt testimonials from our valued clients. 
              Discover why they chose Rentwala for their real estate needs.
            </p>
          </div>
          <Button variant="outline" className="border-[#7B3F00]/30 text-[#7B3F00] hover:text-[#A0522D] transform hover:scale-105 transition-all duration-300 hover:shadow-lg">
            View All Testimonials
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={testimonial.id} className="border-0 shadow-lg hover:shadow-xl transition-all duration-500 hover:-translate-y-2 group animate-slide-up bg-white/90" style={{ animationDelay: `${index * 0.2}s` }}>
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-1">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-[#D2B48C] text-[#7B3F00] animate-pulse-slow" style={{ animationDelay: `${i * 0.1}s` }} />
                    ))}
                  </div>
                  <Quote className="h-6 w-6 text-[#D2B48C] group-hover:text-[#A0522D] transition-colors duration-300" />
                </div>

                <div className="space-y-3">
                  <h3 className="text-lg font-semibold text-[#7B3F00] group-hover:text-[#A0522D] transition-colors duration-300">
                    {testimonial.title}
                  </h3>
                  <p className="text-[#A0522D] leading-relaxed">
                    {testimonial.content}
                  </p>
                </div>

                <div className="flex items-center space-x-3 pt-4 border-t border-[#D2B48C]/30">
                <img
                  src={
                    testimonial.profileImage
                      ? testimonial.profileImage.startsWith("http")
                        ? testimonial.profileImage
                        : `http://localhost:5000${testimonial.profileImage}`
                      : "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100"
                  }
                  alt={testimonial.author}
                  className="w-12 h-12 rounded-full object-cover mr-3 border-2 border-[#D2B48C]"
                />

                  <div>
                    <p className="font-semibold text-[#7B3F00]">{testimonial.author}</p>
                    <p className="text-sm text-[#A0522D]">{testimonial.location}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};