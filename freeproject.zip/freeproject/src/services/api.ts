import { API_CONFIG } from '../config/constants';

const API_BASE_URL = API_CONFIG.BASE_URL;

interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
  error?: string;
  pagination?: {
    currentPage: number;
    totalPages: number;
    totalProperties: number;
    hasNext: boolean;
    hasPrev: boolean;
    limit: number;
  };
}

interface PropertyFilters {
  minPrice?: string;
  maxPrice?: string;
  city?: string;
  type?: string;
  bedrooms?: string;
  search?: string;
  featured?: string;
  sortBy?: string;
  sortOrder?: string;
  page?: number;
  limit?: number;
}

interface Property {
  id: number;
  title: string;
  description: string;
  bedrooms: number;
  bathrooms: number;
  area: string;
  location: string;
  city: string;
  state: string;
  pincode: string;
  price: number;
  priceFormatted: string;
  type: string;
  status: string;
  featured: boolean;
  amenities: string[];
  images: string[];
  createdAt: string;
  updatedAt: string;
}

interface Testimonial {
  id: number;
  title: string;
  content: string;
  author: string;
  location: string;
  profileImage: string;
  rating: number;
  featured: boolean;
  createdAt: string;
  updatedAt: string;
}

interface FAQ {
  id: number;
  question: string;
  answer: string;
  category: string;
  featured: boolean;
  order: number;
  createdAt: string;
  updatedAt: string;
}

class ApiService {
  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<ApiResponse<T>> {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), API_CONFIG.TIMEOUT);

      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        ...options,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        // Try to get error message from response
        let errorMessage = `HTTP error! status: ${response.status}`;
        try {
          const errorData = await response.json();
          errorMessage = errorData.message || errorMessage;
        } catch {
          // If JSON parsing fails, use default error message
        }
        throw new Error(errorMessage);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('API request error:', error);
      
      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          throw new Error('Request timeout. Please try again.');
        }
        throw error;
      }
      
      throw new Error('An unexpected error occurred');
    }
  }

  private async requestWithFormData<T>(endpoint: string, formData: FormData, method: 'POST' | 'PUT' = 'POST'): Promise<ApiResponse<T>> {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), API_CONFIG.TIMEOUT);

      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        method,
        signal: controller.signal,
        body: formData,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        let errorMessage = `HTTP error! status: ${response.status}`;
        try {
          const errorData = await response.json();
          errorMessage = errorData.message || errorMessage;
        } catch {
          // If JSON parsing fails, use default error message
        }
        throw new Error(errorMessage);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('API request error:', error);
      
      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          throw new Error('Request timeout. Please try again.');
        }
        throw error;
      }
      
      throw new Error('An unexpected error occurred');
    }
  }

  // Health check
  async healthCheck(): Promise<ApiResponse<{ message: string; timestamp: string }>> {
    return this.request<{ message: string; timestamp: string }>('/health');
  }

  // Property API methods
  async getProperties(filters: PropertyFilters = {}): Promise<ApiResponse<Property[]>> {
    const queryParams = new URLSearchParams();
    
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        queryParams.append(key, value.toString());
      }
    });

    const queryString = queryParams.toString();
    const endpoint = `/properties${queryString ? `?${queryString}` : ''}`;
    
    return this.request<Property[]>(endpoint);
  }

  async getProperty(id: number): Promise<ApiResponse<Property>> {
    if (!id || isNaN(id)) {
      throw new Error('Invalid property ID');
    }
    return this.request<Property>(`/properties/${id}`);
  }

  // Testimonial API methods
  async getTestimonials(featured?: boolean): Promise<ApiResponse<Testimonial[]>> {
    const queryParams = featured ? '?featured=true' : '';
    return this.request<Testimonial[]>(`/testimonials${queryParams}`);
  }

  // FAQ API methods
  async getFAQs(filters: { category?: string; featured?: boolean } = {}): Promise<ApiResponse<FAQ[]>> {
    const queryParams = new URLSearchParams();
    
    if (filters.category) queryParams.append('category', filters.category);
    if (filters.featured) queryParams.append('featured', 'true');

    const queryString = queryParams.toString();
    const endpoint = `/faqs${queryString ? `?${queryString}` : ''}`;
    
    return this.request<FAQ[]>(endpoint);
  }

  // Admin API methods
  async adminLogin(credentials: { username: string; password: string }): Promise<ApiResponse<{ token: string }>> {
    return this.request<{ token: string }>('/admin/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
  }

  async getAdminProperties(): Promise<ApiResponse<Property[]>> {
    return this.request<Property[]>('/admin/properties');
  }

  async createProperty(propertyData: FormData): Promise<ApiResponse<Property>> {
    return this.requestWithFormData<Property>('/admin/properties', propertyData, 'POST');
  }

  async updateProperty(id: number, propertyData: FormData): Promise<ApiResponse<Property>> {
    return this.requestWithFormData<Property>(`/admin/properties/${id}`, propertyData, 'PUT');
  }

  async deleteProperty(id: number): Promise<ApiResponse<Property>> {
    return this.request<Property>(`/admin/properties/${id}`, {
      method: 'DELETE',
    });
  }

  async getAdminTestimonials(): Promise<ApiResponse<Testimonial[]>> {
    return this.request<Testimonial[]>('/admin/testimonials');
  }

  async createTestimonial(testimonialData: FormData): Promise<ApiResponse<Testimonial>> {
    return this.requestWithFormData<Testimonial>('/admin/testimonials', testimonialData, 'POST');
  }

  async updateTestimonial(id: number, testimonialData: FormData): Promise<ApiResponse<Testimonial>> {
    return this.requestWithFormData<Testimonial>(`/admin/testimonials/${id}`, testimonialData, 'PUT');
  }

  async deleteTestimonial(id: number): Promise<ApiResponse<Testimonial>> {
    return this.request<Testimonial>(`/admin/testimonials/${id}`, {
      method: 'DELETE',
    });
  }

  async getAdminFAQs(): Promise<ApiResponse<FAQ[]>> {
    return this.request<FAQ[]>('/admin/faqs');
  }

  async createFAQ(faqData: Partial<FAQ>): Promise<ApiResponse<FAQ>> {
    return this.request<FAQ>('/admin/faqs', {
      method: 'POST',
      body: JSON.stringify(faqData),
    });
  }

  async updateFAQ(id: number, faqData: Partial<FAQ>): Promise<ApiResponse<FAQ>> {
    return this.request<FAQ>(`/admin/faqs/${id}`, {
      method: 'PUT',
      body: JSON.stringify(faqData),
    });
  }

  async deleteFAQ(id: number): Promise<ApiResponse<FAQ>> {
    return this.request<FAQ>(`/admin/faqs/${id}`, {
      method: 'DELETE',
    });
  }

  async getAdminStats(): Promise<ApiResponse<any>> {
    return this.request<any>('/admin/stats');
  }
}

 const isAuthenticated = () => {
  // Check if token exists in storage
  const token = sessionStorage.getItem('authToken') || localStorage.getItem('token');
  
  if (!token) {
    return false;
  }
  
  // Optional: Check if token is expired (if you're using JWT)
  try {
    const payload = JSON.parse(atob(token.split('.')[1])); 
    const currentTime = Date.now() / 1000;
    
    if (payload.exp && payload.exp < currentTime) {
      // Token expired, remove it
      sessionStorage.removeItem('authToken');
      localStorage.removeItem('token');
      return false;
    }
  } catch (error) {
    // Invalid token format
    return false;
  }
  
  return true;
};

export { isAuthenticated };
export const apiService = new ApiService();
export type { Property, Testimonial, FAQ, PropertyFilters, ApiResponse };
export { API_BASE_URL };