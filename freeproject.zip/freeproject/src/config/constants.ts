// API Configuration
export const API_CONFIG = {
  BASE_URL: 'http://localhost:3001/api',
  TIMEOUT: 10000, 
  RETRY_ATTEMPTS: 3,
  IMG : 'http://localhost:3001'
} as const;


export const CONTACT_INFO = {
  PHONE: {
    PRIMARY: '818181-1678',
    DISPLAY: '+91 818181-1678',
    FORMATTED: '+91 81818-11678',
  },
  EMAIL: {
    PRIMARY: 'property.rentwala@gmail.com',
  },
  ADDRESS: {
    HEADQUARTERS: {
      STREET: 'DLF Cyber City, Sector 25',
      CITY: 'Gurgaon',
      STATE: 'Haryana',
      PINCODE: '122002',
      FULL: 'DLF Cyber City, Sector 25, Gurgaon, Haryana 122002',
    },
  },
  SOCIAL: {
    FACEBOOK: 'https://facebook.com/rentwala',
    TWITTER: 'https://twitter.com/rentwala',
    INSTAGRAM: 'https://instagram.com/rentwala',
    LINKEDIN: 'https://linkedin.com/company/rentwala',
  },
  BUSINESS_HOURS: {
    WEEKDAYS: 'Mon - Fri: 9:00 AM - 7:00 PM',
    WEEKENDS: 'Sat - Sun: 10:00 AM - 5:00 PM',
  },
} as const;

// Company Information
export const COMPANY_INFO = {
  NAME: 'Rentwala',
  TAGLINE: 'Your Dream Property Awaits',
  DESCRIPTION: 'India\'s leading real estate platform dedicated to helping you find your dream property across major Indian cities.',
  ESTABLISHED: '2012',
  EXPERIENCE: '12+',
  LOCATIONS: ['Gurgaon', 'Delhi', 'Noida', 'Faridabad', 'Ghaziabad'],
} as const;

// Statistics
export const STATS = {
  PROPERTIES_SOLD: '25,000+',
  HAPPY_CLIENTS: '15,000+',
  YEARS_EXPERIENCE: '12+',
  SUCCESS_RATE: '99%',
} as const;

// SEO Configuration
export const SEO_CONFIG = {
  DEFAULT_TITLE: 'Rentwala - Find Your Dream Property in India | Real Estate Platform',
  DEFAULT_DESCRIPTION: 'Discover your perfect property with Rentwala, India\'s leading real estate platform. Browse 25,000+ properties across Delhi-NCR, Gurgaon, Noida. Expert agents, transparent pricing, 12+ years experience.',
  DEFAULT_KEYWORDS: 'real estate India, property for sale, buy property Delhi, Gurgaon properties, Noida real estate, property investment, dream home India, real estate agent',
  SITE_URL: 'https://rentwala.com',
  OG_IMAGE: 'https://rentwala.com/og-image.jpg',
  TWITTER_HANDLE: '@rentwala',
} as const;

// Admin Configuration
export const ADMIN_CONFIG = {
  DEFAULT_CREDENTIALS: {
    USERNAME: 'admin',
    PASSWORD: 'admin123',
  },
  SESSION_TIMEOUT: 24 * 60 * 60 * 1000, // 24 hours
} as const;

// File Upload Configuration
export const UPLOAD_CONFIG = {
  MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB
  ALLOWED_IMAGE_TYPES: ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'],
  MAX_IMAGES_PER_PROPERTY: 10,
} as const;

// Pagination Configuration
export const PAGINATION_CONFIG = {
  DEFAULT_PAGE_SIZE: 9,
  MAX_PAGE_SIZE: 50,
  MOBILE_PAGE_SIZE: 6,
} as const;

// Animation Delays
export const ANIMATION_DELAYS = {
  STAGGER: 0.1, // seconds between staggered animations
  FADE_IN: 0.2,
  SLIDE_UP: 0.3,
  BOUNCE_IN: 0.4,
} as const;